﻿using HouseRentingSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace HouseRentingSystem.Controllers
{
    public class HouseController : Controller
    {

        private List<HouseDetailViewModel> houses = new List<HouseDetailViewModel>
        {
            new HouseDetailViewModel()
            {
                Title = "Lake House",
                Address = "Sofia,Bulgaria 33",
                ImageUrl = "https://media1.ispdd.com/projects/big/proekt-za-kashta-Varna-R5rH4-68627028273658452.jpg"
            },
              new HouseDetailViewModel()
            {
                Title = "Lake House",
                Address = "Sofia,Bulgaria 33",
                ImageUrl = "https://media1.ispdd.com/projects/big/proekt-za-kashta-Varna-R5rH4-68627028273658452.jpg"
            },
                new HouseDetailViewModel()
            {
                Title = "Lake House",
                Address = "Sofia,Bulgaria 33",
                ImageUrl = "https://media1.ispdd.com/projects/big/proekt-za-kashta-Varna-R5rH4-68627028273658452.jpg"
            }
        };
        public IActionResult AllHouses()
        {

            return View(houses);
        }
    }
}
