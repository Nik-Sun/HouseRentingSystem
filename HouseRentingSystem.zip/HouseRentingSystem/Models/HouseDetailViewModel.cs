﻿namespace HouseRentingSystem.Models
{
    public class HouseDetailViewModel
    {
        public string Title { get; set; }
        public string Address { get; set; }
        public string ImageUrl { get; set; }
    }
}
